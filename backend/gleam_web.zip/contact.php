<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gleam Education</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/vendors/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="shortcut icon" style="object-fit: cover;" href="./assets/images/favicon.png" type="image/x-icon">

</head>

<body >    
    <?php 
                include('./navbar.php')
    ?>
<div class="container-fluid p-0">

    </div>
    <header class="foi-header">
        <div class="container">
           
        </div>
    </header>
    <div class="container-fluid" style="margin-top: 200px;">
        <div class="row">
    <div class="col-12 col-lg-6 text-center"  id="map" data-aos="fade-right" data-aos-duration="1500">
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5384.130199580666!2d78.45054992372577!3d17.404348805091264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99cd87dc821b%3A0xd4661f404d885852!2sGleam%20Education%20Services!5e0!3m2!1sen!2sin!4v1645709387066!5m2!1sen!2sin"
            width="80%" height="550" style="border:0;" allowfullscreen="" loading="lazy" ></iframe>
    </div>
    <div class="col-12 col-lg-6" style="" data-aos="fade" data-aos-duration="1500" >
        <div class="row">
            <div class="col-12 pl-5 ">        
                <h5 class="">Head Office</h5>
                <div class="row">
                <div class="col-1"><img src="./assets/images/Location Icon.png" width="20px"></div>  <div class="col-10 contact-text contact-text-address" style=" ">202 A, Ashoka Plaza, Masab Tank Beside Hotel Golconda, Hyderabad 500 028. Telangana, India.</p></div>
            </div>
            <div class="row">
                <div class="col-1"><img src="./assets/images/Call icon.png" width="20px"></div>  <div class="col-10 contact-text"><a style=" text-decoration:none;" href="tel:+914066623445"> &nbsp;0091 40 6662 3445/6 </a></p></div>
            </div>
            <div class="row">
                <div class="col-1"><img src="./assets/images/Smartphone icon.png" width="20px"></div><div class="col-10 contact-text"><a style=" text-decoration:none;" href="tel:+919000188007"> &nbsp;9000188007</a></p></div>
            </div>
            <div class="row">
                <div class="col-1"><img src="./assets/images/EMail Icon.png" width="20px"></div> <div class="col-10 contact-text"><a style=" text-decoration:none;" href="mailto:info@gleamrecruits.com"> &nbsp;info@gleamrecruits.com</a></p></div>
            </div>
                <!-- <i class="fa fa-phone"></i><a style="text-decoration:none;" href="tel:+914066623445"> &nbsp;0091 40 6662 3445/6 </a></p>
                <i class="fa fa-mobile"></i><a style="text-decoration:none;" href="tel:+919000188007"> &nbsp; 9000188007</a></p>
                <i class="fa fa-envelope"></i><a style="text-decoration:none;" href="mailto:info@gleamrecruits.com"> &nbsp; info@gleamrecruits.com</a></p> -->
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-6 p-5">
                
                <h5 ckass="mt-5">Branch Office</h5>
                <div class="row">
                    <div class="col-1"><img src="./assets/images/Location Icon.png" width="20px"></div>  <div class="col-10 " style=" "> Suit # 207 B, Babukhan Estate, Bashirbagh, Hyderabad - 500029, Telangana, India</p></div>
                </div>
                <!-- <i class="fa fa-map-marker"></i> &nbsp; Suit # 207 B, Babukhan Estate, Bashirbagh, Hyderabad - 500029, Telangana, India</p> -->
                <div class="row">
                    <div class="col-1"><img src="./assets/images/Smartphone icon.png" width="20px"></div><div class="col-10 "><a style=" text-decoration:none;margin-left: -10px;  overflow-x:visible !important;" href="tel:+914048586512"> &nbsp;+91-4048586512</a></p></div>
                </div>
                <!-- <i class="fa fa-phone"></i><a style="text-decoration:none;" href="tel:+914048586512"> &nbsp;Office Tel : +914048586512 </a></p> -->
                <!-- <i class="fa fa-mobile"></i><a style="text-decoration:none;" href="tel:09000188007"> &nbsp; 9000188007</a></p>
                <i class="fa fa-envelope"></i><a style="text-decoration:none;" href="mailto:info@gleamrecruits.com"> &nbsp; info@gleamrecruits.com</a></p>
                <p> Suit # 207 B, Babukhan Estate, Bashirbagh, Hyderabad - 500029, Telangana, India</p>
                <p>Office Tel : +914048586512</p> -->
        
            </div>
            <div class="col-12 col-md-6 p-5">
                <h5 ckass="mt-5">Branch Office(Vishakhapatnam)</h5>
                <!-- <i class="fa fa-male"></i> &nbsp; Mr. Prasad</p> -->
                <div class="row">
                    <div class="col-1"><img src="./assets/images/Person Icon.png" width="20px"></div>  <div class="col-10 " style=" "> Mr. Prasad</p></div>
                </div>
                <!-- <i class="fa fa-phone"></i><a style="text-decoration:none;" href="tel:+919391003520"> &nbsp;0091 9391003520 </a></p> -->
                <div class="row">
                <div class="col-1"><img src="./assets/images/Smartphone icon.png" width="20px"></div> <div class="col-10 "><a style=" text-decoration:none;margin-left: -10px;" href="tel:+919391003520"> &nbsp;+91-9391003520</a></p></div>
            </div>
            <div class="row">
                <div class="col-1"><img src="./assets/images/EMail Icon.png" width="20px"></div> <div class="col-10 "><a style=" text-decoration:none;" href="mailto:prasad@gleamrecruits.com"> prasad@gleamrecruits.com</a></p></div>
            </div>
            </div>
        </div>
    </div>
</div>
</div>
    <main>
        <div class="container"  >
            <section class="page-header">
                <h2 class="text-center pt-5" >Fill the form to get in touch with us</h2>
            </section>
            <section class="contact-form-wrapper" style="background-image: url(./assets/images/circle-scatter-haikei.svg);background-repeat:repeat-y; background-size: 65%; background-position: 40% 60%;">
                <form action="./backend/contact_data.php" onsubmit="return showloader()" method="POST">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">YOUR NAME <sup>*</sup></label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="email">YOUR EMAIL ADDRESS <sup>*</sup></label>
                            <input type="email" class="form-control" id="email" name="email"
                                placeholder="">
                        </div>
                    </div>
                    <div class="row">
                        <!-- <div class="form-group col-md-6">
                            <label for="subject">SUBJECT <sup>*</sup></label>
                            <input type="text" class="form-control" id="name" name="subject" placeholder="Development">
                        </div> -->
                        <div class="form-group col-md-6">
                            <label for="phone">YOUR PHONE NUMBER <sup>*</sup></label>
                            <input type="text" class="form-control" id="phone" name="phone" placeholder="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-12">
                            <label for="message">HOW CAN WE HELP YOU? <sup>*</sup></label>
                            <textarea name="message" id="message" class="form-control" rows="7"
                                placeholder="Your message ..."></textarea>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary mb-4" style="background-color: #ff3859; border:none;">Submit</button>
                        <p class="form-footer-text">We'll get back to you in 1-2 working days.</p>
                    </div>
                </form>
            </section>
        </div>
    </main>
    <?php 
        include('./footer.php')
    ?>
    <!-- <footer class="foi-footer text-white">
        <div class="container">
            <div class="row footer-content">
                <div class="col-xl-6 col-lg-7 col-md-8">
                    <h2 class="mb-0">Do you want to know more or just have a question? write to us.</h2>
                </div>
                <div class="col-md-4 col-lg-5 col-xl-6 py-3 py-md-0 d-md-flex align-items-center justify-content-end">
                    <a style="text-decoration:none;" href="contact.html" class="btn btn-danger btn-lg">Contact form</a>
                </div>
            </div>
            <div class="row footer-widget-area">
                <div class="col-md-3">
                    <div class="py-3">
                        <img src="assets/images/logo-white.svg" alt="FOI">
                    </div>
                    <p class="font-os font-weight-semibold mb3">Get our mobile app</p>
                    <div>
                        <button class="btn btn-app-download mr-2"><img src="assets/images/ios.svg"
                                alt="App store"></button>
                        <button class="btn btn-app-download"><img src="assets/images/android.svg"
                                alt="play store"></button>
                    </div>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <nav>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Account</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">My tasks</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Projects</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Edit profile</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Activity</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <nav>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#!" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Services</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Careers <span
                                        class="badge badge-pill badge-secondary ml-3">Hiring</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Blog</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link">Shop with us</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <p>
                        &copy; foi. 2020 <a href="https://www.bootstrapdash.com" target="_blank"
                            rel="noopener noreferrer" class="text-reset">BootstrapDash</a>.
                    </p>
                    <p>All rights reserved.</p>
                    <nav class="social-menu">
                        <a href="#!"><img src="assets/images/facebook.svg" alt="facebook"></a>
                        <a href="#!"><img src="assets/images/instagram.svg" alt="instagram"></a>
                        <a href="#!"><img src="assets/images/twitter.svg" alt="twitter"></a>
                        <a href="#!"><img src="assets/images/youtube.svg" alt="youtube"></a>
                    </nav>
                </div>
            </div>
        </div>
    </footer> -->
    <script src="assets/vendors/jquery/jquery.min.js"></script>
    <script src="assets/vendors/popper.js/popper.min.js"></script>
    <script src="assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <?php 
      include('./script.php')
    ?>
</body>

</html>