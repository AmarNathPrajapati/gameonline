<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gleam Education</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/vendors/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="shortcut icon" style="object-fit: cover;" href="./assets/images/favicon.png" type="image/x-icon">

</head>

<body>        
    <?php 
            include('./navbar.php')
    ?>
    <div class="container-fluid p-0">

    </div>
    <header class="foi-header">
        <div class="container">

        </div>
    </header>

    <main style=" padding-top:50px; background-image:url(./assets/images/imagesa.png);  background-repeat: no-repeat;
    background-position:0px -70px; " data-aos="fade-up" data-aos-duration="1500">
        <div class="container">
            <section class="page-header">
                <h2 class="text-center">We can do all this for you</h2>
            </section>
            <section class="foi-page-section" style="margin-top:-90px">
                <div class="row mb-5">
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                            <!--  <span class="p-0 mt-0"><img src="./assets/images/Career Counselling Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                            margin-top: -5px; margin-right: 10px;"></span> -->
                            <span class="p-0 mt-0"><img src="./assets/images/Career Counselling Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                            margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Career counseling</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                            <span class="p-0 mt-0"><img src="./assets/images/Short Listing Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                                margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>University shortlisting.</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                            <span class="p-0 mt-0"><img src="./assets/images/Admission Process Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                                margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Admission process (I20, Offer letter, COE, CAS, Unconditional offers)</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                            <span class="p-0 mt-0"><img src="./assets/images/Education loan Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                                margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Scholarhip assistance (University grants, Indian scholarships)</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                            <span class="p-0 mt-0"><img src="./assets/images/Visa Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                                margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Visa assistance (Mock sessions, Visa application, Forms and submissions etc)</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                             <span class="p-0 mt-0"><img src="./assets/images/Education loan Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                            margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Education loan assistance</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                             <span class="p-0 mt-0"><img src="./assets/images/Travel assist Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                            margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Travel assistance (Currency, cheap airfares)</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 col-12">
                        <div class="media landing-feature">
                             <span class="p-0 mt-0"><img src="./assets/images/Airport Driver Icon.png" alt="CA" style="width: 30px; height: 30px; object-fit: cover; 
                            margin-top: -5px; margin-right: 10px;"></span>
                            <div class="media-body">
                                <h5>Accomodation and airport pick up</h5>
                                <p style="font-size: large; line-height: 1.6rem;">Gleam Education provides all the
                                    necessary services required for your education in foreign.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="pb-md-5">
                <div class="container horizontal-row-part ">
                    <div class="row">
                        <div class="col-12  ">
                            <div class="px-sm-5 text-sm-center" style="color: #191a1b; align-items: center;">
                                <h2 class="text-sm-center exp_gleam"
                                    style="display: inline; align-items: center !important; align-self: center !important;">
                                    Prepare for your foreign education with Us&nbsp; &nbsp;</h2>

                                <button type="button" class="btn" id="requestbtn"
                                    style="background-color: #F5385A; color: white; " data-bs-toggle="modal"
                                    data-bs-target="#schedule_meet_" style="display: grid; place-items: center;">
                                    Request Session
                                </button>
                            </div>
                            <div class="modal fade" id="details" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header border-bottom-0">
                                            <h5 class="modal-title text-center" id="details">Log In</h5>
                                            <button type="button" class="close" data-bs-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <!-- form -->
                                        <form action="./backend/request_session.php" method="POST">
                                            <div class="modal-body">
                                                <div class="form-group" style="padding: 1rem; ">
                                                    <label for="name_req_session" style="">Name</label>
                                                    <input type="text" class="form-control" name="name_req_session"
                                                        id="name" placeholder="Your name">
                                                </div>
                                                <div class="form-group" style="padding: 1rem; color: #323B40;">
                                                    <label for="email_req_session" style="">Email address</label>
                                                    <input type="email" required class="form-control"
                                                        name="email_req_session" id="email1"
                                                        aria-describedby="emailHelp" placeholder="Enter email">
                                                    <!-- <small id="emailHelp" class="form-text text-muted">Your information is safe with us.</small> -->
                                                </div>

                                                <div class="form-group" style="padding: 1rem;">
                                                    <label for="contact_req_session" style="">Contact No.</label>
                                                    <input type="text" class="form-control" name="contact_req_session"
                                                        id="password2" placeholder="Contact no.">
                                                </div>
                                                <div class="form-group col-12">
                                                    <label for="message">HOW CAN WE HELP YOU? <sup>*</sup></label>
                                                    <textarea name="message" id="message" class="form-control" rows="7"
                                                        placeholder="Your message ..."></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-top-0 d-flex justify-content-center">
                                                <button type="submit" class="btn btn-success">Submit</button>
                                                <button class="btn btn-info"><a href="./login.php"
                                                        style="text-decoration: none; color: white;">Sign
                                                        Up</a></button>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>



            <section class="foi-page-section">
                <div class="row">
                    <div class="col-md-6 mb-5 mb-md-0">
                        <img src="assets/images/FAQ Vector-01.png" alt="faq" class="img-fluid" >
                    </div>
                    <div class="col-md-6">
                        <h2 class="feature-faq-title">FAQs</h2>
                        <div class="card feature-faq-card">
                            <div class="card-header bg-white" id="featureFaqOneTitle">
                                <a href="#featureFaqOneCollapse" class="d-flex align-items-center"
                                    data-toggle="collapse">
                                    <h5 class="mb-0">How can I get assistance</h5> <i
                                        class="far fa-plus-square ml-auto"></i>
                                </a>
                            </div>
                            <div id="featureFaqOneCollapse" class="collapse" aria-labelledby="featureFaqOneTitle">
                                <div class="card-body">
                                    <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text
                                        ever since the 1500s, when an unknown printer took a galley of type and
                                        scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card feature-faq-card">
                            <div class="card-header bg-white" id="featureFaqTwoTitle">
                                <a href="#featureFaqTwoCollapse" class="d-flex align-items-center"
                                    data-toggle="collapse">
                                    <h5 class="mb-0">How to apply for visa</h5> <i
                                        class="far fa-plus-square ml-auto"></i>
                                </a>
                            </div>
                            <div id="featureFaqTwoCollapse" class="collapse" aria-labelledby="featureFaqTwoTitle">
                                <div class="card-body">
                                    <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text
                                        ever since the 1500s, when an unknown printer took a galley of type and
                                        scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card feature-faq-card">
                            <div class="card-header bg-white" id="featureFaqThreeTitle">
                                <a href="#featureFaqThreeCollapse" class="d-flex align-items-center"
                                    data-toggle="collapse">
                                    <h5 class="mb-0">How do I Contact gleameducation?</h5> <i
                                        class="far fa-plus-square ml-auto"></i>
                                </a>
                            </div>
                            <div id="featureFaqThreeCollapse" class="collapse" aria-labelledby="featureFaqThreeTitle">
                                <div class="card-body">
                                    <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text
                                        ever since the 1500s, when an unknown printer took a galley of type and
                                        scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card feature-faq-card">
                            <div class="card-header bg-white" id="featureFaqFourTitle">
                                <a href="#featureFaqFourCollapse" class="d-flex align-items-center"
                                    data-toggle="collapse">
                                    <h5 class="mb-0">When I will get callback?</h5> <i
                                        class="far fa-plus-square ml-auto"></i>
                                </a>
                            </div>
                            <div id="featureFaqFourCollapse" class="collapse" aria-labelledby="featureFaqFourTitle">
                                <div class="card-body">
                                    <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text
                                        ever since the 1500s, when an unknown printer took a galley of type and
                                        scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <?php 
        include('footer.php')
    ?>
    <?php 
      include('./script.php')
    ?>
    <script src="assets/vendors/jquery/jquery.min.js"></script>
    <script src="assets/vendors/popper.js/popper.min.js"></script>
    <script src="assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <?php 
      include('./script.php')
    ?>
</body>

</html>